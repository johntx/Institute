CREATE DATABASE IF NOT EXISTS `datos`;

USE datos;

DROP TABLE IF EXISTS `assistances`;

CREATE TABLE `assistances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `inscription_id` int(10) unsigned DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `assistances_inscription_id_foreign` (`inscription_id`),
  KEY `assistances_people_id_foreign` (`people_id`),
  KEY `assistances_subject_id_foreign` (`subject_id`),
  CONSTRAINT `assistances_inscription_id_foreign` FOREIGN KEY (`inscription_id`) REFERENCES `inscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assistances_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assistances_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `careers`;

CREATE TABLE `careers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `duracion` int(11) DEFAULT NULL,
  `mes` int(11) DEFAULT NULL,
  `costo` int(11) DEFAULT NULL,
  `office_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `careers_office_id_foreign` (`office_id`),
  CONSTRAINT `careers_office_id_foreign` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `careers` VALUES("1","TECNOLOGIA","0","4","350","1");
INSERT INTO `careers` VALUES("2","ENFERMERIA ","0","3","350","1");
INSERT INTO `careers` VALUES("3","NORMAL","0","4","320","1");
INSERT INTO `careers` VALUES("4","ECONOMíA","0","4","350","1");
INSERT INTO `careers` VALUES("5","PSICOTECNICO","3","0","250","1");
INSERT INTO `careers` VALUES("6","POL MIL","0","6","470","1");
INSERT INTO `careers` VALUES("7","ENFERMERIA 8:30-10:30","0","2","350","1");



DROP TABLE IF EXISTS `classrooms`;

CREATE TABLE `classrooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `office_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classrooms_office_id_foreign` (`office_id`),
  CONSTRAINT `classrooms_office_id_foreign` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `documents`;

CREATE TABLE `documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ruta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_people_id_foreign` (`people_id`),
  KEY `documents_career_id_foreign` (`career_id`),
  KEY `documents_subject_id_foreign` (`subject_id`),
  CONSTRAINT `documents_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `families`;

CREATE TABLE `families` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ci` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre_completo` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentezco` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `families_people_id_foreign` (`people_id`),
  CONSTRAINT `families_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `functionalities`;

CREATE TABLE `functionalities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `functionalities_code_unique` (`code`),
  UNIQUE KEY `functionalities_path_unique` (`path`),
  KEY `functionalities_menu_id_foreign` (`menu_id`),
  CONSTRAINT `functionalities_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `functionalities` VALUES("1","CMEN","Crear Menu","admin/menu/create","1");
INSERT INTO `functionalities` VALUES("2","EMEN","Editar Menu","admin/menu/edit","1");
INSERT INTO `functionalities` VALUES("3","DMEN","Borar Menu","admin/menu/delete","1");
INSERT INTO `functionalities` VALUES("4","MEN","Ver Menu","admin/menu","1");
INSERT INTO `functionalities` VALUES("5","CFUN","Crear Funcionalidad","admin/functionality/create","2");
INSERT INTO `functionalities` VALUES("6","EFUN","Editar Funcionalidad","admin/functionality/edit","2");
INSERT INTO `functionalities` VALUES("7","DFUN","Borar Funcionalidad","admin/functionality/delete","2");
INSERT INTO `functionalities` VALUES("8","FUN","Ver Funcionalidad","admin/functionality","2");
INSERT INTO `functionalities` VALUES("9","CROL","Crear Roles","admin/role/create","3");
INSERT INTO `functionalities` VALUES("10","EROL","Editar Roles","admin/role/edit","3");
INSERT INTO `functionalities` VALUES("11","DROL","Borar Roles","admin/role/delete","3");
INSERT INTO `functionalities` VALUES("12","ROL","Ver Roles","admin/role","3");
INSERT INTO `functionalities` VALUES("13","CUSR","Crear Usuarios","user/create","4");
INSERT INTO `functionalities` VALUES("14","EUSR","Editar Usuario","user/edit","4");
INSERT INTO `functionalities` VALUES("15","DUSR","Borar Usuarios","user/delete","4");
INSERT INTO `functionalities` VALUES("16","USR","Ver Usuarios","user","4");
INSERT INTO `functionalities` VALUES("17","CEST","Registrar Estudiante","admin/student/create","5");
INSERT INTO `functionalities` VALUES("18","EEST","Editar Estudiante","admin/student/edit","5");
INSERT INTO `functionalities` VALUES("19","DEST","Borar Estudiantes","admin/student/delete","5");
INSERT INTO `functionalities` VALUES("20","EST","Ver Estudiantes","admin/student","5");
INSERT INTO `functionalities` VALUES("21","CDOC","Crear Docente","admin/teacher/create","6");
INSERT INTO `functionalities` VALUES("22","EDOC","Editar Docentes","admin/teacher/edit","6");
INSERT INTO `functionalities` VALUES("23","DDOC","Borar Docentes","admin/teacher/delete","6");
INSERT INTO `functionalities` VALUES("24","DOC","Ver Docentes","admin/teacher","6");
INSERT INTO `functionalities` VALUES("25","COFF","Crear Sucursal","admin/office/create","7");
INSERT INTO `functionalities` VALUES("26","EOFF","Editar Sucursal","admin/office/edit","7");
INSERT INTO `functionalities` VALUES("27","DOFF","Eliminar Sucursal","admin/office/delete","7");
INSERT INTO `functionalities` VALUES("28","OFF","Ver Sucursales","admin/office","7");
INSERT INTO `functionalities` VALUES("29","CCAR","Crear Carrera","admin/career/create","8");
INSERT INTO `functionalities` VALUES("30","ECAR","Editar Carrera","admin/career/edit","8");
INSERT INTO `functionalities` VALUES("31","DCAR","Borrar Carrera","admin/career/delete","8");
INSERT INTO `functionalities` VALUES("32","CAR","Ver Carrerras","admin/career","8");
INSERT INTO `functionalities` VALUES("33","CSUB","Crear Asignatura","admin/subject/create","9");
INSERT INTO `functionalities` VALUES("34","ESUB","Editar Asignatura","admin/subject/edit","9");
INSERT INTO `functionalities` VALUES("35","DSUB","Eliminar Asignatura","admin/subject/delete","9");
INSERT INTO `functionalities` VALUES("36","SUB","Ver Asignaturas","admin/subject","9");
INSERT INTO `functionalities` VALUES("37","CEMP","Crear Empleado","admin/employee/create","10");
INSERT INTO `functionalities` VALUES("38","EEMP","Editar Empleado","admin/employee/edit","10");
INSERT INTO `functionalities` VALUES("39","DEMP","Eliminar Empleado","admin/employee/delete","10");
INSERT INTO `functionalities` VALUES("40","EMP","Ver Empleados","admin/employee","10");
INSERT INTO `functionalities` VALUES("41","CSTA","Crear Convocatoria","admin/startclass/create","11");
INSERT INTO `functionalities` VALUES("42","ESTA","Editar Convocatoria","admin/startclass/edit","11");
INSERT INTO `functionalities` VALUES("43","DSTA","Anular Convocatoria","admin/startclass/delete","11");
INSERT INTO `functionalities` VALUES("44","STA","Ver Convocatoria","admin/startclass","11");
INSERT INTO `functionalities` VALUES("45","CGRO","Crear Grupos","admin/group/create","12");
INSERT INTO `functionalities` VALUES("46","EGRO","Editar Grupos","admin/group/edit","12");
INSERT INTO `functionalities` VALUES("47","DGRO","Anular Grupos","admin/group/delete","12");
INSERT INTO `functionalities` VALUES("48","GRO","Ver Grupos","admin/group","12");
INSERT INTO `functionalities` VALUES("49","CPAY","Registrar Pagos","admin/payment/create","13");
INSERT INTO `functionalities` VALUES("50","EPAY","Editar Pagos","admin/payment/edit","13");
INSERT INTO `functionalities` VALUES("51","DPAY","Anular Pagos","admin/payment/delete","13");
INSERT INTO `functionalities` VALUES("52","PAY","Ver Pagos","admin/payment","13");
INSERT INTO `functionalities` VALUES("53","CINS","Registrar Inscripcio","admin/inscription/create","14");
INSERT INTO `functionalities` VALUES("54","EINS","Editar Inscripcion","admin/inscription/edit","14");
INSERT INTO `functionalities` VALUES("55","DINS","Anular Inscripcion","admin/inscription/delete","14");
INSERT INTO `functionalities` VALUES("56","INS","Ver Inscripcion","admin/inscription","14");
INSERT INTO `functionalities` VALUES("57","CBAC","Crear Backup","admin/backup/create","15");



DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `turno` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startclass_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `groups_startclasses_id_foreign` (`startclass_id`),
  CONSTRAINT `groups_startclasses_id_foreign` FOREIGN KEY (`startclass_id`) REFERENCES `startclasses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `groups` VALUES("16",NULL,"Mañana","Vigente","12");
INSERT INTO `groups` VALUES("17",NULL,"Mañana","Vigente","13");



DROP TABLE IF EXISTS `hours`;

CREATE TABLE `hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hora_inicio` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `hora_fin` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `inscriptions`;

CREATE TABLE `inscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_retiro` date DEFAULT NULL,
  `monto` int(11) DEFAULT NULL,
  `abono` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `colegiatura` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `particular_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `inscriptions_people_id_foreign` (`people_id`),
  KEY `inscriptions_career_id_foreign` (`career_id`),
  KEY `inscriptions_group_id_foreign` (`group_id`),
  KEY `inscriptions_particular_id_foreign` (`particular_id`),
  KEY `inscriptions_user_id_foreign` (`user_id`),
  CONSTRAINT `inscriptions_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inscriptions_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inscriptions_particular_id_foreign` FOREIGN KEY (`particular_id`) REFERENCES `particulars` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inscriptions_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `inscriptions` VALUES("37","Inscrito",NULL,"320","320","960","Debe","66","2","16",NULL,"2","2017-12-12 14:59:11","2017-12-12 14:59:11");
INSERT INTO `inscriptions` VALUES("38","Inscrito",NULL,"320","320","960","Debe","67","2","16",NULL,"2","2017-12-12 15:04:45","2017-12-12 15:04:45");
INSERT INTO `inscriptions` VALUES("39","Inscrito",NULL,"320","320","960","Debe","68","2","16",NULL,"2","2017-12-12 15:07:02","2017-12-12 15:07:02");
INSERT INTO `inscriptions` VALUES("40","Inscrito",NULL,"320","320","960","Debe","69","2","16",NULL,"2","2017-12-12 15:08:33","2017-12-12 15:08:33");
INSERT INTO `inscriptions` VALUES("41","Inscrito",NULL,"320","320","960","Debe","70","2","16",NULL,"2","2017-12-12 15:09:50","2017-12-12 15:09:50");
INSERT INTO `inscriptions` VALUES("42","Inscrito",NULL,"300","300","900","Debe","71","2","16",NULL,"2","2017-12-12 15:15:01","2017-12-12 15:15:01");
INSERT INTO `inscriptions` VALUES("43","Inscrito",NULL,"320","320","960","Debe","72","2","16",NULL,"2","2017-12-12 15:19:16","2017-12-12 15:26:38");
INSERT INTO `inscriptions` VALUES("44","Inscrito",NULL,"320","320","640","Debe","73","7","17",NULL,"2","2017-12-12 21:32:42","2017-12-12 21:32:42");
INSERT INTO `inscriptions` VALUES("45","Inscrito",NULL,"350","50","700","Debe","74","7","17",NULL,"2","2017-12-12 21:34:08","2017-12-12 21:34:08");
INSERT INTO `inscriptions` VALUES("46","Inscrito",NULL,"350","50","700","Debe","75","7","17",NULL,"2","2017-12-12 21:39:06","2017-12-12 21:39:06");
INSERT INTO `inscriptions` VALUES("47","Inscrito",NULL,"350","350","700","Debe","76","7","17",NULL,"2","2017-12-12 21:40:36","2017-12-12 21:40:36");
INSERT INTO `inscriptions` VALUES("48","Inscrito",NULL,"350","150","700","Debe","77","7","17",NULL,"2","2017-12-12 21:45:31","2017-12-12 21:45:31");



DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `label` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `menus` VALUES("1","MMEN","Menus","bars");
INSERT INTO `menus` VALUES("2","MFUN","Funcionalidades","bar-chart");
INSERT INTO `menus` VALUES("3","MROL","Roles","key");
INSERT INTO `menus` VALUES("4","MUSR","Usuarios","user");
INSERT INTO `menus` VALUES("5","MCLI","Estudiantes","users");
INSERT INTO `menus` VALUES("6","MDOC","Docentes","male");
INSERT INTO `menus` VALUES("7","MOFF","Sucursal","home");
INSERT INTO `menus` VALUES("8","MCAR","Carreras","car");
INSERT INTO `menus` VALUES("9","MSUB","Asignaturas","book");
INSERT INTO `menus` VALUES("10","MEMP","Empleados","briefcase");
INSERT INTO `menus` VALUES("11","MSTA","Convocatoria","info");
INSERT INTO `menus` VALUES("12","MGRO","Grupos","cubes");
INSERT INTO `menus` VALUES("13","MPAY","Pagos","dollar");
INSERT INTO `menus` VALUES("14","MINS","Inscripciones","file-text");
INSERT INTO `menus` VALUES("15","MBAC","Backup Base De Datos","download");



DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `migrations` VALUES("2014_09_12_000000_create_roles_table","1");
INSERT INTO `migrations` VALUES("2014_10_12_000000_create_users_table","1");
INSERT INTO `migrations` VALUES("2014_10_12_100000_create_password_resets_table","1");
INSERT INTO `migrations` VALUES("2017_06_23_104730_create_menus_table","1");
INSERT INTO `migrations` VALUES("2017_06_23_104740_create_functionalities_table","1");
INSERT INTO `migrations` VALUES("2017_06_23_104752_create_privileges_table","1");
INSERT INTO `migrations` VALUES("2017_10_24_200719_create_offices_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_175414_create_peoples_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_175744_create_careers_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_180505_create_partials_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_180538_create_notices_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_180730_create_families_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_181749_create_subjects_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_181857_create_startclasses_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182002_create_documents_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182051_create_groups_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182140_create_particulars_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182141_create_inscriptions_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182303_create_assistances_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_182849_create_scores_table","1");
INSERT INTO `migrations` VALUES("2017_11_17_183026_create_payments_table","1");
INSERT INTO `migrations` VALUES("2017_11_28_151704_create_weekly_table","1");
INSERT INTO `migrations` VALUES("2017_11_28_152022_create_teaches_table","1");
INSERT INTO `migrations` VALUES("2017_11_28_153525_create_hours_table","1");
INSERT INTO `migrations` VALUES("2017_11_28_153607_create_classrooms_table","1");
INSERT INTO `migrations` VALUES("2017_11_28_153642_create_schedules_table","1");



DROP TABLE IF EXISTS `notices`;

CREATE TABLE `notices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `tipo` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `titulo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `texto` text COLLATE utf8_unicode_ci,
  `foto` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notices_user_id_foreign` (`user_id`),
  CONSTRAINT `notices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `offices`;

CREATE TABLE `offices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `offices` VALUES("1","INSTITUTO CIEN CENTRAL COCHABAMBA","C/Jordan #681, e/ Antezana y Lanza, Edif. Ferrufino Of. 4");



DROP TABLE IF EXISTS `partials`;

CREATE TABLE `partials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `particulars`;

CREATE TABLE `particulars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `abono` int(11) DEFAULT NULL,
  `saldo` int(11) DEFAULT NULL,
  `costo` int(11) DEFAULT NULL,
  `hora_inicio` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hora_fin` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `particulars_people_id_foreign` (`people_id`),
  KEY `particulars_career_id_foreign` (`career_id`),
  CONSTRAINT `particulars_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `particulars_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_pagar` date DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `abono` int(11) DEFAULT NULL,
  `saldo` int(11) DEFAULT NULL,
  `inscription_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `payments_inscription_id_foreign` (`inscription_id`),
  KEY `payments_user_id_foreign` (`user_id`),
  CONSTRAINT `payments_inscription_id_foreign` FOREIGN KEY (`inscription_id`) REFERENCES `inscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `payments` VALUES("57","2017-11-15","2017-12-12",NULL,"Pagado","320","320","37","2","2017-12-12 14:59:11","2017-12-12 14:59:11");
INSERT INTO `payments` VALUES("58","2017-12-15",NULL,NULL,"Pendiente","0","320","37","2","2017-12-12 14:59:11","2017-12-12 14:59:11");
INSERT INTO `payments` VALUES("59","2017-11-15","2017-12-12",NULL,"Pagado","320","320","38","2","2017-12-12 15:04:45","2017-12-12 15:04:45");
INSERT INTO `payments` VALUES("60","2017-12-15",NULL,NULL,"Pendiente","0","320","38","2","2017-12-12 15:04:45","2017-12-12 15:04:45");
INSERT INTO `payments` VALUES("61","2017-11-15","2017-12-12",NULL,"Pagado","320","320","39","2","2017-12-12 15:07:02","2017-12-12 15:07:02");
INSERT INTO `payments` VALUES("62","2017-12-15",NULL,NULL,"Pendiente","0","320","39","2","2017-12-12 15:07:02","2017-12-12 15:07:02");
INSERT INTO `payments` VALUES("63","2017-11-15","2017-12-12",NULL,"Pagado","320","320","40","2","2017-12-12 15:08:33","2017-12-12 15:08:33");
INSERT INTO `payments` VALUES("64","2017-12-15",NULL,NULL,"Pendiente","0","320","40","2","2017-12-12 15:08:33","2017-12-12 15:08:33");
INSERT INTO `payments` VALUES("65","2017-11-15","2017-12-12",NULL,"Pagado","320","320","41","2","2017-12-12 15:09:50","2017-12-12 15:09:50");
INSERT INTO `payments` VALUES("66","2017-12-15",NULL,NULL,"Pendiente","0","320","41","2","2017-12-12 15:09:50","2017-12-12 15:09:50");
INSERT INTO `payments` VALUES("67","2017-11-15","2017-12-12",NULL,"Pagado","300","300","42","2","2017-12-12 15:15:01","2017-12-12 15:15:01");
INSERT INTO `payments` VALUES("68","2017-12-15",NULL,NULL,"Pendiente","0","300","42","2","2017-12-12 15:15:01","2017-12-12 15:15:01");
INSERT INTO `payments` VALUES("69","2017-11-15","2017-12-12",NULL,"Pagado","150","320","43","2","2017-12-12 15:19:16","2017-12-12 15:19:16");
INSERT INTO `payments` VALUES("70","2017-11-22","2017-12-12","","Pagado","170","170","43","2","2017-12-12 15:19:16","2017-12-12 15:26:37");
INSERT INTO `payments` VALUES("71","2017-12-15",NULL,NULL,"Pendiente","0","320","43","2","2017-12-12 15:26:38","2017-12-12 15:26:38");
INSERT INTO `payments` VALUES("72","2017-12-15","2017-12-12",NULL,"Pagado","320","320","44","2","2017-12-12 21:32:42","2017-12-12 21:32:42");
INSERT INTO `payments` VALUES("73","2018-01-15",NULL,NULL,"Pendiente","0","320","44","2","2017-12-12 21:32:42","2017-12-12 21:32:42");
INSERT INTO `payments` VALUES("74","2017-12-15","2017-12-12",NULL,"Pagado","50","350","45","2","2017-12-12 21:34:08","2017-12-12 21:34:08");
INSERT INTO `payments` VALUES("75","2017-12-22",NULL,NULL,"Pendiente","0","300","45","2","2017-12-12 21:34:08","2017-12-12 21:34:08");
INSERT INTO `payments` VALUES("76","2017-12-15","2017-12-12",NULL,"Pagado","50","350","46","2","2017-12-12 21:39:06","2017-12-12 21:39:06");
INSERT INTO `payments` VALUES("77","2017-12-22",NULL,NULL,"Pendiente","0","300","46","2","2017-12-12 21:39:06","2017-12-12 21:39:06");
INSERT INTO `payments` VALUES("78","2017-12-15","2017-12-12",NULL,"Pagado","350","350","47","2","2017-12-12 21:40:36","2017-12-12 21:40:36");
INSERT INTO `payments` VALUES("79","2018-01-15",NULL,NULL,"Pendiente","0","350","47","2","2017-12-12 21:40:37","2017-12-12 21:40:37");
INSERT INTO `payments` VALUES("80","2017-12-15","2017-12-12",NULL,"Pagado","150","350","48","2","2017-12-12 21:45:31","2017-12-12 21:45:31");
INSERT INTO `payments` VALUES("81","2017-12-22",NULL,NULL,"Pendiente","0","200","48","2","2017-12-12 21:45:31","2017-12-12 21:45:31");



DROP TABLE IF EXISTS `peoples`;

CREATE TABLE `peoples` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ci` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `paterno` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `materno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `nacionalidad` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado_civil` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `genero` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_sanguineo` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `office_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peoples_code_unique` (`code`),
  KEY `peoples_office_id_foreign` (`office_id`),
  CONSTRAINT `peoples_office_id_foreign` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `peoples` VALUES("2",NULL,"787878","eduardo","barriga","m.","2017-11-29","0000-00-00","",NULL,"","",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("66",NULL,"9472947","NOELIA EVELYN","MEDRANO MIRANDA","MIRANDA","2017-11-15","0000-00-00",NULL,NULL,NULL,"70768370",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("67",NULL,"14852908","ALIZON","ZENTENO"," ","2017-11-15","1999-08-01",NULL,NULL,NULL,"78310195 ",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("68",NULL,"13259799","JHOELI ","ZENTENO ESCALERA","ESCALERA","2017-11-15","2000-06-23",NULL,NULL,NULL,"77911321",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("69",NULL,"9389607","ALEJANDRA ANAHI","PERALTA ARGOTE","ARGOTE","2017-11-15","1999-03-08",NULL,NULL,NULL,"77975557",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("70",NULL,"13352664","JHENNY","QUISPE VILLARROEL","VILLARROEL","2017-11-15","1996-12-15",NULL,NULL,NULL,"68500669",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("71",NULL,"9476770","MARIA LIZBETH","CHAVEZ QUINTEROS","QUINTEROS","2017-11-15","1995-10-31",NULL,NULL,NULL,"68531995",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("72",NULL,"14195791","GLADIS ","MARTINES VILLEGAS","VILLEGAS","2017-11-15","1997-08-08",NULL,NULL,NULL,"75935460",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("73",NULL,"8757057","NALIA ","LOPEZ VILLARROEL",NULL,"2017-12-12","2017-12-04",NULL,NULL,NULL,"75383684",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("74",NULL,"6529994","LUIS ANTONIO","HUALLPA MAMANI",NULL,"2017-12-12","1997-01-20",NULL,NULL,NULL,"78339978",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("75",NULL,"9444156","KARINA EVELIN","TORREZ CARBAJAL",NULL,"2017-12-12","2000-01-27",NULL,NULL,NULL,"79960790",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("76",NULL,"","ELIANA ","ROJAS VIA",NULL,"2017-12-12","0000-00-00",NULL,NULL,NULL,"",NULL,NULL,NULL,"1");
INSERT INTO `peoples` VALUES("77",NULL,"","MILENA ","FUENTES PARRILLO",NULL,"2017-12-12","2000-01-18",NULL,NULL,NULL,"65396647",NULL,NULL,NULL,"1");



DROP TABLE IF EXISTS `privileges`;

CREATE TABLE `privileges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `functionality_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `privileges_functionality_id_foreign` (`functionality_id`),
  KEY `privileges_role_id_foreign` (`role_id`),
  CONSTRAINT `privileges_functionality_id_foreign` FOREIGN KEY (`functionality_id`) REFERENCES `functionalities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `privileges_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=489 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `privileges` VALUES("373","17","5");
INSERT INTO `privileges` VALUES("374","18","5");
INSERT INTO `privileges` VALUES("375","20","5");
INSERT INTO `privileges` VALUES("376","21","5");
INSERT INTO `privileges` VALUES("377","22","5");
INSERT INTO `privileges` VALUES("378","24","5");
INSERT INTO `privileges` VALUES("379","41","5");
INSERT INTO `privileges` VALUES("380","42","5");
INSERT INTO `privileges` VALUES("381","44","5");
INSERT INTO `privileges` VALUES("382","45","5");
INSERT INTO `privileges` VALUES("383","46","5");
INSERT INTO `privileges` VALUES("384","48","5");
INSERT INTO `privileges` VALUES("385","49","5");
INSERT INTO `privileges` VALUES("386","50","5");
INSERT INTO `privileges` VALUES("387","52","5");
INSERT INTO `privileges` VALUES("388","53","5");
INSERT INTO `privileges` VALUES("389","54","5");
INSERT INTO `privileges` VALUES("390","56","5");
INSERT INTO `privileges` VALUES("448","1","1");
INSERT INTO `privileges` VALUES("449","2","1");
INSERT INTO `privileges` VALUES("450","3","1");
INSERT INTO `privileges` VALUES("451","4","1");
INSERT INTO `privileges` VALUES("452","5","1");
INSERT INTO `privileges` VALUES("453","6","1");
INSERT INTO `privileges` VALUES("454","7","1");
INSERT INTO `privileges` VALUES("455","8","1");
INSERT INTO `privileges` VALUES("456","9","1");
INSERT INTO `privileges` VALUES("457","10","1");
INSERT INTO `privileges` VALUES("458","11","1");
INSERT INTO `privileges` VALUES("459","12","1");
INSERT INTO `privileges` VALUES("460","13","1");
INSERT INTO `privileges` VALUES("461","14","1");
INSERT INTO `privileges` VALUES("462","15","1");
INSERT INTO `privileges` VALUES("463","16","1");
INSERT INTO `privileges` VALUES("464","17","1");
INSERT INTO `privileges` VALUES("465","18","1");
INSERT INTO `privileges` VALUES("466","19","1");
INSERT INTO `privileges` VALUES("467","20","1");
INSERT INTO `privileges` VALUES("468","21","1");
INSERT INTO `privileges` VALUES("469","22","1");
INSERT INTO `privileges` VALUES("470","23","1");
INSERT INTO `privileges` VALUES("471","24","1");
INSERT INTO `privileges` VALUES("472","25","1");
INSERT INTO `privileges` VALUES("473","26","1");
INSERT INTO `privileges` VALUES("474","27","1");
INSERT INTO `privileges` VALUES("475","28","1");
INSERT INTO `privileges` VALUES("476","29","1");
INSERT INTO `privileges` VALUES("477","30","1");
INSERT INTO `privileges` VALUES("478","31","1");
INSERT INTO `privileges` VALUES("479","32","1");
INSERT INTO `privileges` VALUES("480","37","1");
INSERT INTO `privileges` VALUES("481","38","1");
INSERT INTO `privileges` VALUES("482","39","1");
INSERT INTO `privileges` VALUES("483","40","1");
INSERT INTO `privileges` VALUES("484","45","1");
INSERT INTO `privileges` VALUES("485","46","1");
INSERT INTO `privileges` VALUES("486","47","1");
INSERT INTO `privileges` VALUES("487","48","1");
INSERT INTO `privileges` VALUES("488","57","1");



DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`),
  UNIQUE KEY `roles_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `roles` VALUES("1","ROOT","ROOT",NULL);
INSERT INTO `roles` VALUES("2","ADM","Administrador",NULL);
INSERT INTO `roles` VALUES("3","EST","Estudiante",NULL);
INSERT INTO `roles` VALUES("4","DOC","Docente",NULL);
INSERT INTO `roles` VALUES("5","REG","REGISTROS",NULL);
INSERT INTO `roles` VALUES("6","DIS","Deshabilitado",NULL);



DROP TABLE IF EXISTS `schedules`;

CREATE TABLE `schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semana` int(11) DEFAULT NULL,
  `hour_id` int(10) unsigned DEFAULT NULL,
  `classroom_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_hour_id_foreign` (`hour_id`),
  KEY `schedules_classroom_id_foreign` (`classroom_id`),
  KEY `schedules_subject_id_foreign` (`subject_id`),
  KEY `schedules_career_id_foreign` (`career_id`),
  CONSTRAINT `schedules_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schedules_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schedules_hour_id_foreign` FOREIGN KEY (`hour_id`) REFERENCES `hours` (`id`) ON DELETE SET NULL,
  CONSTRAINT `schedules_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `scores`;

CREATE TABLE `scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inscription_id` int(10) unsigned DEFAULT NULL,
  `people_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `partial_id` int(10) unsigned DEFAULT NULL,
  `nota` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `scores_inscription_id_foreign` (`inscription_id`),
  KEY `scores_people_id_foreign` (`people_id`),
  KEY `scores_group_id_foreign` (`group_id`),
  KEY `scores_subject_id_foreign` (`subject_id`),
  KEY `scores_partial_id_foreign` (`partial_id`),
  CONSTRAINT `scores_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scores_inscription_id_foreign` FOREIGN KEY (`inscription_id`) REFERENCES `inscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scores_partial_id_foreign` FOREIGN KEY (`partial_id`) REFERENCES `partials` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scores_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scores_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `startclasses`;

CREATE TABLE `startclasses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `startclasses_career_id_foreign` (`career_id`),
  CONSTRAINT `startclasses_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `startclasses` VALUES("12","Iniciado","2017-11-15","2018-03-14","2");
INSERT INTO `startclasses` VALUES("13","Espera","2017-12-15","2018-02-14","7");



DROP TABLE IF EXISTS `subjects`;

CREATE TABLE `subjects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `subjects` VALUES("1","MATEMATICAS");
INSERT INTO `subjects` VALUES("2","PSICOLOGIA");
INSERT INTO `subjects` VALUES("3","LENGUAJE");
INSERT INTO `subjects` VALUES("4","FISICA");
INSERT INTO `subjects` VALUES("5","QUIMICA");
INSERT INTO `subjects` VALUES("6","BIOLOGIA");



DROP TABLE IF EXISTS `teaches`;

CREATE TABLE `teaches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `people_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teaches_people_id_foreign` (`people_id`),
  KEY `teaches_subject_id_foreign` (`subject_id`),
  CONSTRAINT `teaches_people_id_foreign` FOREIGN KEY (`people_id`) REFERENCES `peoples` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teaches_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_unique` (`user`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` VALUES("1","john","$2y$10$G3APTqEBJ3iADrUr40WV2u3VvzLVJ4xRWrClP4WCPj9hRDAgwu3pa","1","z70C3R2c5JIfrVWiVNoxH31sHjXdJkN60fpGSgQYNi4ifay1kdF2oV0kOFle","2017-07-07 17:18:12","2017-07-17 10:47:33",NULL);
INSERT INTO `users` VALUES("2","reg","$2y$10$SjREU9n1D2BqHKg1cgjHY.bHJKfLTZ82628IaUVu5TTWVGLRxTKH.","5","w0qYfHQ7CF5bFb2s4dpA3qjuaCSllyAhmKMACemkrB8GK1bZgXKj2i66uDWA","0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("66","CIEN-66","$2y$10$AmC6AWEL1Iza2FCPSdrMC.HuzZdsCgaCIxfHGxtM7yj62RaP1eU6K","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("67","CIEN-67","$2y$10$KqFiZ6Waz7.XRnUiUdsOXugVWsihA0ibCAu8yj0AoZpg5DojKaTfa","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("68","CIEN-68","$2y$10$G43eG0kDLn6yThfw/stKyuXtpB3weXzWvSOOtAXR5lmohxYatxvQi","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("69","CIEN-69","$2y$10$DYOV5XrvVHzTgxfZoEtMxeEHG28D9Wiq8lRziQd5MgUd3Q3Oh/Fsu","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("70","CIEN-70","$2y$10$twV3Wmk5LlZCTUIIMrh5QeYoiTuYSWdvIbI3N7Y7QP7rNxRbASZB2","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("71","CIEN-71","$2y$10$2leA02ZoHqxqHccHbO3kjuObokxkkEUYLhuF8JVCLJKDwuvpkA.Lq","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("72","CIEN-72","$2y$10$YwJn5gsgO1OKXwGRy5SuFeZ4c/rXgyO3BtGQKbrlpi7NMTxIxiusa","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("73","CIEN-73","$2y$10$FghPo/a8mRHsoKfRXdUub.TwsQDSZa1/oIBaHVT3oMpHkEftJJM/u","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("74","CIEN-74","$2y$10$LD20yPAO.DngKQJjNT93juDBzPjxgBOCmLFUac3Ia.OA3f1TgHFWO","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("75","CIEN-75","$2y$10$7N5GsqbuozJYm.Go32sMyO71rzc9I/fXcC0hhhL6ioqJh.N5eEgPW","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("76","CIEN-76","$2y$10$R9MQpsJx196zpwK0yd5qfedy3RzdIyER/J6Lh5czYIjqzahCyav9S","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);
INSERT INTO `users` VALUES("77","CIEN-77","$2y$10$WtHsneu/0UdCRgXMRI0yfueHydJjSyOgZDfqvBgMB1MdKANvFAOBC","3",NULL,"0000-00-00 00:00:00","0000-00-00 00:00:00",NULL);



DROP TABLE IF EXISTS `weekly`;

CREATE TABLE `weekly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nota` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `career_id` int(10) unsigned DEFAULT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `weekly_career_id_foreign` (`career_id`),
  KEY `weekly_subject_id_foreign` (`subject_id`),
  CONSTRAINT `weekly_career_id_foreign` FOREIGN KEY (`career_id`) REFERENCES `careers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `weekly_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

